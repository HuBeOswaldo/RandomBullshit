# Changelog

## v1.0.7

- Fixed local DPS text updates for multiplayer hits by observing outgoing
  training-dummy damage RPCs on the attacking player's client.
- Kept DPS sampling hits that continue after dummy health reaches its 1 HP
  floor, where health-difference-based sampling stopped registering damage.
- Increased both training dummies to 500,000 health for extended training
  sessions.

## v1.0.6

- Fixed multiplayer DPS visibility so each player sees damage from their own
  attacks on training dummies placed by other players.

## v1.0.5

- Fixed the T.W.I.G. example image format so it renders correctly on the
  Thunderstore and GitHub mod pages.

## v1.0.4

- Prevented damage from destroying training dummies or dropping their build
  materials. Dismantling still returns the materials normally.
- Removed the "DPS" label prefix and reduced the size of the displayed number.

## v1.0.3

- Added T.W.M. (Training with Mexicanito), a passive training dummy in the
  hammer build menu.
- Added DPS labels above T.W.I.G. and T.W.M., calculated over a rolling
  5-second window.
- Made both training dummies indestructible; they recover to full health after
  5 seconds without damage.
- DPS labels disappear after 5 seconds without a hit.
